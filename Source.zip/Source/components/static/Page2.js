import React, { Component } from 'react';

//===============================================================================================//

class BlankPageTemplate extends Component {
    render() {
        return (
            <div className="backgroundTest">
                    Blank page template. Ignore me!
            </div>
        );
    }
}

export default BlankPageTemplate;